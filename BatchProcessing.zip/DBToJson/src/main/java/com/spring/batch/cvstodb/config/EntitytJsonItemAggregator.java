package com.spring.batch.cvstodb.config;

import org.springframework.batch.item.file.transform.LineAggregator;

import com.fasterxml.jackson.core.JsonProcessingException;


public class EntitytJsonItemAggregator<T> implements LineAggregator<T> {

	@Override
	public String aggregate(T entity) {
		// TODO Auto-generated method stub
		String result = null;
		try {
			result = JsonUtils.convertObjectToJsonString(entity); 
		} catch (JsonProcessingException jpe) {
			System.out.println("An error has occured. Error message {} "+ jpe.getMessage() );
		}
		return result;
	}

}